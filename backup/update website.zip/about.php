<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<title lang="en-US" lang="en-IN">MAJDOOR PVT.LTD</title>
		
		 <link rel="icon" href="logo/mainLogo.ico" type="image/x-icon">
		 
		
		
		<!-- Bootstrap Core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!-- Custom Fonts -->
		<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!-- Custom CSS -->
		<link rel="stylesheet" href="css/patros.css" >

<style>
#example1 {
    
    background: url(images/bg-01.jpg);
   background-repeat: no-repeat;
    background-size: 100%,100%;
}
</style>


	
	</head>
	

<body id="example1">

	

		
		<!-- Navigation -->
		<nav class="navbar navbar-inverse navbar-fixed-top">
			<div class="container">
			
			<img src="images/mainLogo.jpg" class="mainLogo" width="50%" alt="KARIGAR">
			
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
			
				</div>							
	
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right custom-menu" style="font-family:OpenSans-CondBold;">
						<li class="active"><a href="index.html">Home</a></li>
					
				<!--		<li><a href="gallery.html">Gallery</a></li>-->
				
						<li>	<a href="How.html">How we work..?</a></li>  
						<li><a href="#rate.html">Rate Card</a></li> 
						<li><a href="product.php">My shop</a></li> 
						<li><a href="services.html">Services</a></li>
						<li><a href="career.php">CAREER</a></li>
						<li><a href="about.php">About us</a></li>
						<li><a href="contact.php">contact us</a></li>
					</ul>
				</div>
			</div>
		</nav>
			<div class="home-col"> -->
	<h1> MISSION</h1>
<p><font face="verdana" color="green">Our mission is to enable co-workers or customers to enjoy or provide their favorite work that they are 
interesting any time,anywhere through a simple and easy to use online service.
</font></p>
</div>
		</body>
	
	</html>