     <aside id="slide-out" class="side-nav white fixed">
                <div class="side-nav-wrapper">
                    <div class="sidebar-profile">
                        <div class="sidebar-profile-info">
                       <img src ="favicon.png" alt="loading">
                         
                        </div>
                    </div>

            <aside id="slide-out" class="side-nav white fixed">
                <div class="side-nav-wrapper">


                <ul class="sidebar-menu collapsible collapsible-accordion" data-collapsible="accordion" style="">
                    <li>&nbsp;</li>
					
                    <li class="no-padding">
					<a class="waves-effect waves-grey" href="user/"><i class="material-icons">
					account_box</i>User Login</a>
					</li>
                    <li class="no-padding">
					<a class="waves-effect waves-grey" href="index.php"><i class="material-icons">
					account_box</i>Employe Login</a>
					</li>
               <!--    <li class="no-padding"><a class="waves-effect waves-grey" href="#forgot-password.php">
					<i class="material-icons">account_box</i>Emp Password Recovery</a></li>
-->
                       <li class="no-padding"><a class="waves-effect waves-grey" href="admin/">
					   <i class="material-icons">account_box</i>Admin Login</a></li>

                </ul>
                   <div class="footer">
                    <p class="copyright"><a href="http://www.code-projects.org/">© Copyright OK(ourkarigar.com).</a></p>
                
                </div>
                </div>
            </aside>