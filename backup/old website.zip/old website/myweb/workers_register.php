
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title lang="en-US" lang="en-IN">OURKARIGAR PVT. LTD. Company</title>
<link rel="icon" href="logo/mainLogo.ico" type="image/x-icon">
<meta name="description" content="एक विश्वसनीय समुदाय बाजार जगह है जहां लोग और व्यापार कुशल पाने और कारीगर की सत्यापित एक उचित मूल्य पर और एक समय पर ढंग अपने कार्य को पूरा करने के लिए कर सकते हैं। हमारा उद्देश्य हमारे बहुत ही पेशेवर और अनुभवी सत्यापित कर्मचारियों की संख्या के माध्यम से, बकाया ऑनलाइन ग्राहक सेवा और तकनीकी विशेषज्ञता उपलब्ध कराने के द्वारा ग्राहक के जीवन को बेहतर बनाने के लिए ह    our mission:-
Our mission is to enable co-workers to enjoy 
provide their favoite work that they are 
intersting any time anywhere through a simple and easy to use online service.
ourkarigar.com ै।">
<meta name="keywords" content="Invented to facilitate: enhance the people life by providing trusted and beneficial online services platform, to solve the problem.">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/patros.css">
<link rel="stylesheet" href="css/demo.css">
<link rel="stylesheet" href="css/footer-distributed.css">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<style>
p {
  text-align: center;
  font-size: 60px;
  margin-top: 0px;
}
</style>
<style>
.dropbtn {
    background-color: #25C7D9;
    color: black;
    padding: 8px;
    font-size: 18px;
    border: none;
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.btn {
    background-color: DodgerBlue;
    border: none;
    color: white;
    padding: 2px 5px;
    cursor: pointer;
    font-size: 15px;
}

/* Darker background on mouse-over */
.btn:hover {
    background-color: RoyalBlue;
}
</style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
<div class="container">
<img src="logo/new.png" class="mainLogo" width="50%" alt="KARIGAR">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav navbar-right custom-menu" style="font-family:OpenSans-CondBold;">
<li><a href="login.php" target="blank">LOGIN</a></li>
<li><a href="https://ourkarigar.com/How.html">How we work..?</a></li>
<li><a href="product.php">My shop</a></li>
<li><a href="https://ourkarigar.com/services.html">Services</a></li>
<li><a href="user.php">User <br>Registration</a></li>
<li><a href="workers_register.php">Worker<br> Registration</a></li>
</div>
</ul>
</div>
</div>
</nav>	
		

<!--  33Navigation 
    
    <img src="images/android-banner.png" style= "background-size:cover; width:100%; height: auto;" class="ebanner">-->
		
		<section id="register" ><h1></h1>
		<font color="red"> <marquee behavior="scroll" direction="left" scrollamount="4"  onmouseover="this.stop();"
           onmouseout="this.start();" bgcolor="Yellow"><strong>NOTE : </strong>All fields are mandatory & for ID proof you can uplaod your Aadhar card or voter card with current loaction.</marquee></font>
		<div class="container"><div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'en,hi,ur', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
		<div class="row">
			<div class="text-center">
			<font color="Blue"> <h2>Workers Registration</h2></font>
			</div>
			
			<div class="main-content">
			<div class="register">
						<form method="post" action="worker_insert.php" enctype="multipart/form-data">
<table>
<tr>
<td><b>Full Name*:</b></td>
<td><input type='text' name='name' placeholder='ENTER YOUR FULL NAME' required></td>
</tr>
<tr>
<td><b>Father Name*:</b></td>
<td><input type='text' name='fn' placeholder='ENTER YOUR FATHER NAME' required></td>
</tr>
<tr>
<td><b>Picture*:</b></td>
<td><input type='file' name='cp' required></td>
</tr>
<tr>
<td><b>DOB*:</b></td>
<td><input type='date' name='dob' required></td>
</tr>
<tr>
<td><b>Gender*:</b></td>
<td><input type='Radio' name='cg' value='Male' required>Male<input type='Radio' name='cg' value='Female' required>Female</td>
</tr>
<tr>
<tr>
<td><b>MOBILE NO*.:</b></td>
<td><input type='mobile' name='mob' required></td>
</tr>

<tr>
<td><b>ID Proof*:</b></td>
<td><input type='file' name='id'  required></td>
</tr>
</tr>
<tr>
<td><b>Address*:</b></td>
<td><textarea rows='3' cols='25' name='add' required>
</textarea>
</td>
</tr>	
<tr>
<td><b>Select your Occupation *:</b></td>
<td>
<select name='oc' required>
    <option value="0">Select Worker:</option>
    <option value="painter">Painter</option>
    <option value="Talse/flooring">Talse/Flooring</option>
    <option value="Plumber">Plumber</option>
    <option value="Electrician">Electrician</option>
    <option value="Thekedaar">Thekedaar</option>
    <option value="Labour">Labour</option>
    <option value="Carpenter">Carpenter</option>
    <option value="Architect">Architect</option>
    <option value="Glass Work">Glass Work</option>
    <option value="Gypsum Ceiling">Gypsum Ceiling</option>
    <option value="Interior Designer">Interior Designer</option>
    
</select>
</td>
</tr>					
							
							


</table>
<br><br>
<input type='submit'>
<input type='reset'>
</form>
</div> 
</div>
</div>
</section>
			
		<footer class="footer-distributed">
<div class="footer-right">
<a href="https://www.facebook.com/ourkarigar.page.9"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="fa fa-twitter"></i></a>
<a href="https://plus.google.com/u/0/117348525981164985545"><i class="fa fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCjZkzI_be3XBlM24Cn1qWJA"><i class="fa fa-youtube"></i></a>
<a href="#"><i class="fa fa-google-plus"></i></a>
<a href="https://drive.google.com/file/d/1Kbj3YT-tkl-WUpSB2KTAOYOGB295_m49/view?usp=drivesdk">
<button class="btn"><i class="fa fa-download"></i>Download our app</button>
</a>
</div>
<div class="footer-left">
<p class="footer-links">
<a href="index.html">Home</a>
|
<a href="Site is under maintainance.html">Our team</a>
|
<a href="Site is under maintainance.html">Career</a>
|
<a href="about.php">About</a>
|
<a href="contact.php">Feedback</a>
|
<a href="contact.php">Contact-us</a>
</p>
<p><u>OURKARIGAR PVT. LTD. COMPANY &copy; 2018</u></p>
<p>
<a href="Site is under maintainance.html">T&C</a>
|
<a href="Site is under maintainance.html">privacy policy</a>
</p>
</div>
</footer><div style='text-align: right;position: fixed;z-index:9999999;bottom: 0; width: 100%;cursor: pointer;line-height: 0;display:block !important;'><a title="Hosted on free web hosting 000webhost.com. Host your own website for FREE." target="_blank" href="https://www.000webhost.com/?utm_source=000webhostapp&amp;utm_campaign=000_logo&amp;utm_medium=website_ourkarigar&amp;utm_content=footer_img"><img src="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png" alt="www.000webhost.com"></a></div><div style='text-align: right;position: fixed;z-index:9999999;bottom: 0; width: 100%;cursor: pointer;line-height: 0;display:block !important;'><a title="Hosted on free web hosting 000webhost.com. Host your own website for FREE." target="_blank" href="https://www.000webhost.com/?utm_source=000webhostapp&amp;utm_campaign=000_logo&amp;utm_medium=website_ourkarigar&amp;utm_content=footer_img"><img src="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png" alt="www.000webhost.com"></a></div></body>
</html>
