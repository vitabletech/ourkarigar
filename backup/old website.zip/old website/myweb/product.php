<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Our product</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>
<style>
#example1 {
    
    background: url(images/bg1.jpeg);
   background-repeat: no-repeat;
    background-size: 100%,100%;
}
</style>

<body id="example1">
  	<nav class="product-filter">

	<div class="sort">
			<div class="collection-sort">
				<!--	<label>Filter by:</label>
				<select>
		      <option value="/">All Products</option>
		      <option value="/">MyCem</option>
		      <option value="/">jypee</option>
		      <option value="/">Prism</option>
		      <option value="/">Ultratech</option>
		      <option value="/">------</option>
		      <option value="/">------</option>
		      <option value="/">------</option>
		   	</select>
			</div>
			
			<div class="collection-sort">
				<label>Sort by:</label>
				<select>
		      <option value="/">Featured</option>
		      <option value="/">Best Selling</option>
		      <option value="/">Alphabetically, A-Z</option>
		      <option value="/">Alphabetically, Z-A</option>
		      <option value="/">Price, low to high</option>
		      <option value="/">Price, high to low</option>
		      <option value="/">Date, new to old</option>
		      <option value="/">Date, old to new</option>
		    </select>
			</div>
		</div>	-->	<div align="center"><h1>Our products</h1></div>
        
	</nav>
	
	<a href="index.html">
            <img width="60" height="50" alt="Back to home" title="Karigar" src="./Karigar _ How_files/logo.png">
          </a>
	<section class="products">
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>Sand</h5>
				<h6>rs.5000</h6>
			</div>
		</div>
		
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>Cement</h5>
				<h6>300</h6>
			</div>
		</div>
		
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>product comming soon.....</h5>
				<h6>rs.</h6>
			</div>
		</div>
		
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>product comming soon.....</h5>
				<h6>rs.</h6>
			</div>
		</div>
		
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>product comming soon.....</h5>
				<h6>rs.</h6>
			</div>
		</div>
		
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>product comming soon.....</h5>
				<h6>rs.</h6>
			</div>
		</div>
		
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>product comming soon.....</h5>
				<h6>rs.</h6>
			</div>
		</div>
		
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>product comming soon.....</h5>
				<h6>rs.</h6>
			</div>
		</div>
		
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>product comming soon.....</h5>
				<h6>rs.</h6>
			</div>
		</div>
		
		<div class="product-card">
			<div class="product-image">
				<img src="images/bg7.jpeg">
			</div>
			<div class="product-info">
				<h5>product comming soon.....</h5>
				<h6>rs.</h6>
			</div>
		</div>
		
	</section>
  
  

</body>

</html>
